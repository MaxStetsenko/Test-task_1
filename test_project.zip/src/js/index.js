import "./import/modules";

import $ from "jquery";
import PerfectScrollbar from 'perfect-scrollbar';
import Swiper, { Navigation, Pagination } from 'swiper';
// configure Swiper to use modules
Swiper.use([Navigation, Pagination]);


const selectBody = document.querySelectorAll('.select__body');
selectBody.forEach(item => {
	const ps = new PerfectScrollbar(item, {
		wheelSpeed: 2,
		suppressScrollX: "true",
		minScrollbarLength: 40,
		suppressScrollX: true,
		wheelPropagation: false,
	});

})



$(document).ready(function () {
	$('.select__header').on('click', function () {
		$(this).next().slideToggle(200);
		$('.mainslider__dotts').css('z-index', '-1');
	});
	$('.select__item').on('click', function () {
		let itemText = $(this).text();
		let selectParent = $(this).parent();
		let selectHeader = selectParent.prev();
		selectHeader.children('.select__current').html(itemText);
		selectParent.slideToggle(200);
		$('.mainslider__dotts').css('z-index', '1');
	});
});



const mainSlider = new Swiper('.main__slider', {
	// Optional parameters
	observeParents: true,
	slidesPerView: 4,
	spaceBetween: 35,
	autoHeight: false,
	speed: 800,
	updateOnWindowResize: true,
	// loop: true,
	// If we need pagination
	pagination: {
		el: '.mainslider__dotts',
		clickable: true,
	},
	breakpoints: {
		// when window width is >= 320px
		240: {
			slidesPerView: 1,
			spaceBetween: 50
		},
		576: {
			slidesPerView: 2,
			spaceBetween: 20,
		},
		// when window width is >= 480px
		992: {
			slidesPerView: 3,
			spaceBetween: 20
		},
		// when window width is >= 640px
		1200: {
			slidesPerView: 4,
			spaceBetween: 35
		}
	}

});